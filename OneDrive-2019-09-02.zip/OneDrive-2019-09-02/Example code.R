set.seed(12345)
library(BMDS)
doses <- sort(rep(c(0,10,20,40,80,160),10))

y <- 5 + 5*plogis(-2.5+0.1*doses) +rlnorm(length(doses),0,0.8)
y <- 5 + 0.1*(doses/160)^2.2 +rlnorm(length(doses),0,0.5)

#Hill Priors
priorH<-    matrix(c(2,0,1,0,18,
                     1,1,2,-18,18,
                     2,log(0.5),1,0,18,
                     2,log(1.5),0.250099980007996,0,18,
				     2,0,1,0,18,
                     1,0,1,-18,18),6,5,byrow=T)

LpriorH<-    matrix(c(2,0,1,0,18,
                      1,1,2,-18,18,
                      2,log(0.5),1,0,18,
                      2,log(1.5),0.250099980007996,0,18,
                      1,0,1,-18,18),5,5,byrow=T)

#Exponential 
priorE5<-    matrix(c(2,0,1, 0,1e6, # a
                      2,0,1, 0,18,     # b
                      1,0,1, -20,20,    # log(c)
                      2,0,0.250099980007996,0,18, #d 
                      2,0,0.5,0,18, 
                      1,0,1,-18,18),6,5,byrow=T)

LpriorE5<-    matrix(c(2,0,1,0,1e6, # a
  	                   2,0,1, 0,18,     # b
      	               1,0,1, -20,20,    # log(c)
           		       2,0,0.250099980007996,0,18, #d 
                       1,0,1,-18,18),5,5,byrow=T)

#Power 
priorPow<-    matrix(c(2,0,1,0,1e6, # a
                       1,0,1,  -1e4,1e4,     # b
                       2,log(1.5),0.5, 0,40,  #k
                       2,0,0.250099980007996,0,18,
                       1,0,1,-18,18),5,5,byrow=T)

LpriorPow<-    matrix(c(2,0,1,0,1e6, # a
                        1,0,1,  -1e4,1e4,     # b
                        2,log(1.5),0.5, 0,18,  #k
                        1,0,1,-18,18),4,5,byrow=T)


bmd_single_continuous('exp-5','STDev',cbind(doses,y),LpriorE5,is_log_normal=T,sstat=F
                      ,BMRF = 1, bkg_prob=0.05,alpha=0.05)
bmd_single_continuous('exp-5','STDev',cbind(doses,y),LpriorE5,is_log_normal=F,sstat=F,
                        BMRF = 0.1, bkg_prob=0.05,alpha=0.05,constVar=T)
bmd_single_continuous('exp-5','STDev',cbind(doses,y),priorE5,is_log_normal=F,sstat=F,
                        BMRF = 0.1, bkg_prob=0.05,alpha=0.05,constVar=F)


bmd_single_continuous('exp-3','Hybrid',cbind(doses,y),LpriorE5,is_log_normal=T,sstat=F
                      ,BMRF = 0.1, bkg_prob=0.05,alpha=0.05)
bmd_single_continuous('exp-3','Hybrid',cbind(doses,y),LpriorE5,is_log_normal=F,sstat=F,
                        BMRF = 0.1, bkg_prob=0.05,alpha=0.05,constVar=T)
bmd_single_continuous('exp-3','Hybrid',cbind(doses,y),priorE5,is_log_normal=F,sstat=F,
                        BMRF = 0.1, bkg_prob=0.05,alpha=0.05,constVar=F)


a = bmd_single_continuous('hill','STDev',cbind(doses,y),LpriorH,is_log_normal=T,sstat=F
                      ,BMRF = 0.01, bkg_prob=0.05,alpha=0.01)
bmd_single_continuous('hill','STDev',cbind(doses,y),LpriorH,is_log_normal=F,sstat=F,
                        BMRF = 0.1, bkg_prob=0.05,alpha=0.05,constVar=T)
bmd_single_continuous('hill','STDev',cbind(doses,y),priorH,is_log_normal=F,sstat=F,
                        BMRF = 1, bkg_prob=0.05,alpha=0.05,constVar=F)

bmd_single_continuous('power','Hybrid',cbind(doses,y),LpriorPow,is_log_normal=T,sstat=F
                      ,BMRF = 0.1,  bkg_prob=0.05,alpha=0.05)
bmd_single_continuous('power','Hybrid',cbind(doses,y),LpriorPow,is_log_normal=F,sstat=F,
                        BMRF = 0.1, bkg_prob=0.05,alpha=0.05,constVar=T)
bmd_single_continuous('power','Hybrid',cbind(doses,y),priorPow,is_log_normal=F,sstat=F,
                        BMRF = 0.1, bkg_prob=0.05,alpha=0.05,constVar=F)


