set.seed(12345)
#CXX_STD=CXX14
doses <- sort(rep(c(0,10,20,40,80,160),10))

y <- 2 + 5*plogis(-2.5+0.1*doses) +rnorm(length(doses))

VB <- mean(y[doses==0])

y <- y/VB

dataM <- cbind(doses/160,y); 
SS   <- FALSE; 

uID <- unique(dataM[,1])
M = matrix(0,nrow=6,ncol=4)
M[,1] <- uID
M[,3] <- 10

for (ii in 1:length(uID)){
  M[ii,2] = mean(dataM[uID[ii]==dataM[,1],2])
  M[ii,4] = sd(dataM[uID[ii]==dataM[,1],2])
}
  

model = 5; 

#Hill Priors
priorH<-    matrix(c(2,0,1,0,18,
                     1,1,2,-18,18,
                     2,log(0.5),10,0,18,
                     2,0,10,1.00E-08,18,
                     1,0,10,-18,18,
                     2,0,1,1.00E-08,18),6,5,byrow=T)

#Hill Priors
priorH<-    matrix(c(2,0,1,0,18,
                     1,1,2,-18,18,
                     2,log(0.5),10,0,18,
                     2,0,10,1.00E-08,18,
                     2,0,1,0,18,
                     1,0,1,1.-18,18),6,5,byrow=T)

#Exponential 
priorE5<-    matrix(c(1,1,2,-1e6,1e6, # a
                     2,0,2, 0,100,     # b
                    1,0,1, -40,40,    # log(c)
                    2,0,0.250099980007996,1.00E-08,18, #d 
                    2,0,0.5,0,18, 
                    1,0,0.250099980007996,-18,18),6,5,byrow=T)

#Power 
priorPow<-    matrix(c(1,1,2,-1e6,1e6, # a
                      1,0,10,  0,1e4,     # b
                      2,0,3, 0,40,  #k
                      1,0,0.5,-18,18, 
                      2,0,0.250099980007996,1.00E-08,1),5,5,byrow=T)

options <- c(2,0.05,0.01,F,1.0,0,0); 
x <- doses/(max(doses))

library(BMDS)
run_continuous_ma(6,as.matrix(y),as.matrix(x),priorH,FALSE,options = options) #exponential - 5

priorH<-    matrix(c(1,1,10,0,18, #b
                     2,0,1,0,100, # b
                     2,log(0.5),0.5,0,18, # k
                     2,0,0.5,0,18,  # n
                     2,0,0.5,0,18, #power term
                     1,0,10,-18,18),6,5,byrow=T) #log variance

system.time({run_continuous_ma(6,as.matrix(y),as.matrix(x),priorH,FALSE,options = options)}) #HILL

run_continuous_ma(8,as.matrix(y),as.matrix(x),priorPow,FALSE,options = options) #power


#6 = Hill
#8 = power

testD <-  matrix(c(0    ,  96.3,5,1.316,
                   39.01, 100.5,5,1.104,
                   331.5, 156.5,5,1.27 ,
                   2935 , 185.1,5,1.257),nrow=4,ncol=4,byrow=T)

options <- c(2,0.05,0.1,F,1,0,0);  #note T implies nonconstant variance F, constant
g2<-run_single_continuous(2,
                         testD,  priorE5,
                         TRUE ,  options)
options <- c(2,0.05,0.1,F,1,0,0);  #note T implies nonconstant variance F, constant
g3<-run_single_continuous(3,
                         testD,  priorE5,
                         TRUE ,  options)
options <- c(2,0.05,0.1,F,1,0,0);  #note T implies nonconstant variance F, constant
g4<-run_single_continuous(4,
                         testD,  priorE5,
                         TRUE ,  options)
options <- c(3,0.05,0.1,F,0.05,0,0);  #note T implies nonconstant variance F, constant
g5<-run_single_continuous(5,
                         testD,  priorE5,
                         TRUE ,  options)
