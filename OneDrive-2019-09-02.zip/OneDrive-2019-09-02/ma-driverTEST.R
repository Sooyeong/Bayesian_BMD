set.seed(12345)
library(BMDS)
doses <- sort(rep(c(0,10,20,40,80,160),10))

y <- 5 + 4*plogis(-2.5+0.2*doses)+rnorm(length(doses),0,0.7)
#y <- exp(log(y) + rnorm(length(doses),0,0.05))
#y <- y+rnorm(length(doses),0,0.25*y^0.5)
plot(doses,y)
#y <- 5 + 0.1*(doses/160)^2.2 +rlnorm(length(doses),0,0.5)
system.time({a <- bmd_ma('Hybrid',cbind(doses,y),PR=NA,sstat=F,BMRF = 0.1,
                bkg_prob=0.01,alpha=0.05)})


#detach("package:BMDS", unload=TRUE)

