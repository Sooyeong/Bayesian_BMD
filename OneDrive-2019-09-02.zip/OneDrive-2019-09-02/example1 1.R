library(BMDS)


mData <- matrix(c(0, 0,5,
                  0.1, 2,5,
                  0.3, 3,5,
                  1, 4,5,
                  10,5,5,
                  30,5,5),nrow=6,ncol=3,byrow=T)

mData <- matrix(c(0, 0,5,
                  0.1, 2,5,
                  0.3, 3,5,
                  1, 4,5,
                  10,5,5),nrow=5,ncol=3,byrow=T)

p = pgamma(mData[,1]*2.47257,1,1)
like = p^mData[,3]*(1-p)^(mData[,2]-mData[,3])


o1 <- c(0.1,0.05, -9999)
o2 <- c(1,2)

prior <- matrix(c(0,	-18,	2,	-18,	18,
                  0,	1.001,	0.424264068711929,	1,	18,
                  0,	1,	1,	0,	10000),nrow=3,ncol=5,byrow=T)

bmd_single_dichotomous("gamma",mData,o1,o2,PR=prior,isBAYES = F)

prior <- matrix(c(1,	0,	2,	-20,	20,
                  1,	0,	1,	-40,	40,
                  2,	0.693147180559945,	0.5,	1.00E-04,	1e4),nrow=3,ncol=5,byrow=T)

prior <- matrix(c(1,	0,	2,	-18,	18,
                  2,	0.693147180559945,	0.424264068711929,	0.2,	20,
                  2,	0,	1.5,	0,	1e4),nrow=3,ncol=5,byrow=T)

bmd_single_dichotomous("gamma",mData,o1,o2,PR=prior,isBAYES = T)
bmd_single_dichotomous("gamma",mData,o1,o2,isBAYES = T)

bmd_single_dichotomous("gamma",mData,o1,o2,isBAYES = F)$bmd

bmd_single_dichotomous("log-probit",mData,o1,o2,isBAYES = T)$bmd
bmd_single_dichotomous("log-probit",mData,o1,o2,isBAYES = F)$bmd

bmd_single_dichotomous("weibull",mData,o1,o2,isBAYES = T)$bmd
bmd_single_dichotomous("weibull",mData,o1,o2,isBAYES = F)$bmd

