library(BMDS)


mData <- matrix(c(0, 0,5,
                  0.1, 2,5,
                  0.3, 3,5,
                  1, 4,5,
                  10,5,5,
                  30,5,5),nrow=6,ncol=3,byrow=T)


o1 <- c(0.1,0.05, -9999)
o2 <- c(2,2)



a<-bmd_single_dichotomous("multistage",mData,o1,o2,isBAYES = F)
b<-bmd_single_dichotomous("gamma",mData,o1,o2,isBAYES = T)
           

prior <- matrix(c(0,	-2,	2,	-8,	8,
                  0,	 0.1,	1,	  0,	18),nrow=2,ncol=5,byrow=T)

c<-bmd_single_dichotomous("qlinear",mData,o1,o2,isBAYES = F)
d<-bmd_single_dichotomous("qlinear",mData,o1,o2,isBAYES = T)

e<-bmd_single_dichotomous("probit",mData,PR=prior,o1,o2,isBAYES = F)
f<-bmd_single_dichotomous("probit",mData,o1,o2,isBAYES = T)

g<-bmd_single_dichotomous("log-logistic",mData,o1,o2,isBAYES = F)
h<-bmd_single_dichotomous("log-logistic",mData,o1,o2,isBAYES = T)


